
import React from 'react';
import './App.css';
const Navbar = () => {
  return (
    <nav className="navbar">
      <h2>Flashcard Quiz</h2>
    </nav>
  );
};

export default Navbar;
